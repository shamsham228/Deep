name = 'Deep-Live-Cam'
version = '2.0c'
edition = 'GitHub Edition'
